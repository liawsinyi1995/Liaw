﻿Imports System.Net.Mail

Public Class SendEmail
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub btnSend_Click(sender As Object, e As EventArgs) Handles btnSend.Click
        Dim sMessage As String = ""
        Dim Mail As New MailMessage
        Dim SMTP As New SmtpClient("smtp.gmail.com")

        Mail.Subject = tbSubject.Text
        Mail.From = New MailAddress("liawsinyi567@gmail.com")
        SMTP.Credentials = New System.Net.NetworkCredential("liawsinyi567@gmail.com", "</li8wsinyi567/>")

        Mail.To.Add(tbTo.Text)
        Mail.CC.Add("dev.ng@outlook.com")
        Mail.Body = tbBody.Text
        Mail.IsBodyHtml = True

        Dim oFile As New Attachment(Server.MapPath("~") & "BSOA\" & "Exam.docx")


        SMTP.DeliveryMethod = SmtpDeliveryMethod.Network
        SMTP.EnableSsl = True
        SMTP.Port = "587"

        Try
            SMTP.Send(Mail)
            sMessage = "Email has been sent successfully"

        Catch ex As Exception
            sMessage = "Email Send Failure:" & ex.ToString


        End Try
        lblStatus.Text = sMessage




    End Sub
End Class